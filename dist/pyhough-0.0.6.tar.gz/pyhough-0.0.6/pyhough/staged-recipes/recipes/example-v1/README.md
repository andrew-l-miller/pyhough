# V1 recipe format

This recipe is an example of the v1 recipe format that was defined by [CEP 13](https://github.com/conda/ceps/blob/main/cep-13.md). The v1 recipe format is fully functional when built with rattler-build, but is not yet fully supported by conda-forge's automation.

See https://github.com/conda-forge/conda-forge.github.io/issues/2308 for progress on general support for this new format.
